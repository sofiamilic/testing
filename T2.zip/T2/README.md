#  Tarea 2 Testing  

### Integrantes
 - Sofía Miic
 - Renato Van de Wyngard

 ### Trabajo realizado por
 
Sofía Milic: Implementacion de métricas en el instrumentor
- Frecuencia
- Tiempo de ejecucion
- Callers
- Cacheable

Renato Van de Wyngard: Implementacion Call Context Tree


